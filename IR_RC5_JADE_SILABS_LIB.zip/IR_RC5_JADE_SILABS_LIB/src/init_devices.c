/*
 * init_devices.c
 *
 *  Created on: 3 de may. de 2020
 *      Author: steckler
 */


#include "em_device.h"
#include "em_cmu.h"
#include "em_emu.h"
#include "em_gpio.h"
#include "em_prs.h"
#include "em_system.h"
#include "em_timer.h"
#include "em_chip.h"
#include "string.h"
#include "math.h"


#define PWM_FREQ 36000UL
#define HALF_BIT_FREQ (PWM_FREQ/32)
#define WTIMER0_PRESCALE timerPrescale1


// Init Timer0 to output 36 kHz, 25% duty cycle pulses when enabled
void TIMER0_init(void) {
  /* Enable clock for TIMER0 module */
  CMU_ClockEnable(cmuClock_TIMER0, true);

  /* Select CC channel parameters */
  TIMER_InitCC_TypeDef timerCCInit = {
      .eventCtrl = timerEventEveryEdge,
      .edge = timerEdgeBoth,
      .prsSel = timerPRSSELCh0,
      .cufoa = timerOutputActionNone,
      .cofoa = timerOutputActionNone,
      .cmoa = timerOutputActionToggle,
      .mode = timerCCModePWM,
      .filter = false,
      .prsInput = false,
      .coist = false,
      .outInvert = false, };

  /* Configure CC channel 0 */
  TIMER_InitCC(TIMER0, 0, &timerCCInit);

  // Route to PD10
  TIMER0->ROUTEPEN |= TIMER_ROUTEPEN_CC0PEN;
  TIMER0->ROUTELOC0 |= _TIMER_ROUTELOC0_CC0LOC_LOC18; //PD10 salida del led IR

  uint32_t top = CMU_ClockFreqGet(cmuClock_HFPER) / PWM_FREQ;

  /* Set Top Value */
  TIMER_TopSet(TIMER0, top);

  /* Set compare to top/4 for 25% duty cycle */
  TIMER_CompareBufSet(TIMER0, 0, top / 4);

  /* Select timer parameters */
  TIMER_Init_TypeDef timerInit = {
      .enable = false,
      .debugRun = true,
      .prescale =
      timerPrescale1,
      .clkSel = timerClkSelHFPerClk,
      .fallAction = timerInputActionNone,
      .riseAction = timerInputActionNone,
      .mode = timerModeUp,
      .dmaClrAct = false,
      .quadModeX4 = false,
      .oneShot = false,
      .sync = false, };

  /* Configure timer */
  TIMER_Init(TIMER0, &timerInit);
}


void WTIMER0_init(void) //phototransistor
{
  // Enable clock for TIMER0 module
  CMU_ClockEnable(cmuClock_WTIMER0, true);

  TIMER_InitCC_TypeDef timerCCInit = TIMER_INITCC_DEFAULT;
  // Set interrupt on falling edge
  timerCCInit.eventCtrl = timerEventEveryEdge;
  timerCCInit.edge = timerEdgeBoth;
  timerCCInit.mode = timerCCModeCapture;
  TIMER_InitCC(WTIMER0, 2, &timerCCInit);

  WTIMER0->ROUTELOC0 |= WTIMER_ROUTELOC0_CC2LOC_LOC31;
  WTIMER0->ROUTEPEN |= WTIMER_ROUTEPEN_CC2PEN;

  // Initialize timer with defined prescale value
  TIMER_Init_TypeDef timerInit = TIMER_INIT_DEFAULT;
  timerInit.prescale = WTIMER0_PRESCALE;
  TIMER_Init(WTIMER0, &timerInit);

  // Safely enable TIMER0 interrupts
  TIMER_IntClear(WTIMER0, WTIMER_IF_CC2 | WTIMER_IF_OF);
  NVIC_ClearPendingIRQ(WTIMER0_IRQn);
  TIMER_IntEnable(WTIMER0, WTIMER_IF_CC2 | WTIMER_IF_OF);
  NVIC_EnableIRQ(WTIMER0_IRQn);
}

// Handle the RC-5 packet transmission
// Init TIMER1 to overflow every half-bit period: 889us
void TIMER1_init(void)
{
  /* Enable clock for TIMER0 module */
  CMU_ClockEnable(cmuClock_TIMER1, true);

  uint32_t top = CMU_ClockFreqGet(cmuClock_HFPER) / HALF_BIT_FREQ;

  /* Set Top Value */
  TIMER_TopSet(TIMER1, top);

  /* Select timer parameters */
  TIMER_Init_TypeDef timerInit = {
      .enable = false,
      .debugRun = true,
      .prescale =
      timerPrescale1,
      .clkSel = timerClkSelHFPerClk,
      .fallAction = timerInputActionNone,
      .riseAction = timerInputActionNone,
      .mode = timerModeUp,
      .dmaClrAct = false,
      .quadModeX4 = false,
      .oneShot = false,
      .sync = false, };

  /* Configure timer */
  TIMER_Init(TIMER1, &timerInit);

  /* Enable overflow interrupt */
  TIMER_IntEnable(TIMER1, TIMER_IF_OF);

  /* Enable TIMER1 interrupt vector in NVIC */
  NVIC_EnableIRQ(TIMER1_IRQn);
}
