#include "em_device.h"
#include "em_cmu.h"
#include "em_emu.h"
#include "em_gpio.h"
#include "em_prs.h"
#include "em_system.h"
#include "em_timer.h"
#include "em_chip.h"
#include "string.h"
#include "math.h"
#include "init_devices.h"
#include "ir.h"


 //typedef union RC_5_received_ RC_5_received;
#define OUTPUT_PORT gpioPortD
#define OUTPUT_PIN 10
#define HFPERCLK_IN_MHZ 19
#define WTIMER0_PRESCALE timerPrescale1

volatile uint32_t RC_5_bit;
volatile bool RC_5_TX_complete = false;
volatile uint32_t  r = 0;
volatile bool edge = 0;
// Default clock and prescale values
// Most recent measured period in microseconds
volatile uint32_t measured_period;
// Stored edge from previous interrupt
volatile uint32_t last_captured_edge;
// Number of timer overflows since last interrupt;
volatile uint32_t overflow_count;
/* RC5  bits time definitions */
uint16_t RC5TimeOut = 0;
uint32_t RC5_Data = 0;
uint32_t i = 0;
bool bit = 1;
uint32_t temp_data=0;
uint16_t periodsArray[80];

tRC5_packet   RC5TmpPacket;          /*!< First empty packet */

void RC_5_transmit(uint32_t toggle, uint32_t addr, uint32_t command);
void RC_5_init(void);


int main(void) {
  /* Initialize chip */
  CHIP_Init();

  // Init DCDC regulator with kit specific parameters
  EMU_DCDCInit_TypeDef dcdcInit = EMU_DCDCINIT_DEFAULT;
  EMU_DCDCInit(&dcdcInit);

  SystemCoreClockUpdate();
  CMU_HFRCOBandSet(cmuHFRCOFreq_19M0Hz);
  CMU_ClockSelectSet(cmuClock_HF, cmuSelect_HFRCO);
  /* Enable clock for GPIO module */
  CMU_ClockEnable(cmuClock_GPIO, true);
  GPIO_PinModeSet(OUTPUT_PORT, OUTPUT_PIN, gpioModePushPull, 0);//salida IR
  // Configure WTIMER0 CC2 Location 31 (PD11) as input
  GPIO_PinModeSet(gpioPortD, 11, gpioModeInput, 1);//PD11 entrada fototransistor
  // Initialize the RC-5 hardware

  /* Default state */
  RC5_ResetPacket();

  RC_5_init();
  uint32_t delay;
  uint32_t command = 0;
  uint32_t addr = 0;


  while (1) {
	//pbuffer = (uint32_t*)&periodsArray[0];

	RC5_ResetPacket();

	RC_5_init();

	//RC_5_transmit(1, addr, command);
	RC_5_transmit(1, addr,command);

    // wait for the transmission to complete
    while(!RC_5_TX_complete);


    ReInitDecoderRc5();
   // RC5_Decode(&RC5_FRAME);
     RC5_Decode();

    // Delay for some short period of time
    for (delay = 0; delay < 0x8000; delay++);


    // Increment the command part of the packet.
    // This is only 6 bits, so if we've gone past 0x3F, reset to zero
    command++;
    addr++;
	if (addr > 0x1F) { addr = 0; }
    if (command > 0x3F) { command = 0; }

  }
}







void TIMER1_IRQHandler(void)
{
  static bool bitState = 0;
  bool currentBit;
  /* Clear flag for TIMER1 overflow interrupt */
  TIMER_IntClear(TIMER1, TIMER_IF_OF);

  // If we've transmitted bit 13, turn everything off and exit.
  // Indicate that the transmission is complete
  if (RC_5_bit == 14) {
	RC_5_transmission.data = temp_data;

    TIMER_Enable(TIMER1, 0);
    TIMER_Enable(TIMER0, 0);
    bitState = 0;
    RC_5_TX_complete = true;
    return;
  }
  // Get the current bit
  currentBit = (RC_5_transmission.data ) & (0x1 << 13);

  // If we're in the first half-bit-period, and the bit is a 1, transmit pulses by enabling TIMER0
  // If we're in the second half-bit period, and the bit is a 0, transmit pulses by enabling TIMER0
  // Otherwise hold low by disabling TIMER0
  if (bitState == currentBit) {
    TIMER_CounterSet(TIMER0, 0);
    TIMER_Enable(TIMER0, 1);
  } else {
    TIMER_Enable(TIMER0, 0);
  }

  // If we just completed the second bit period, increment to the next bit
  // Shift the transmission data right once
  if (bitState) {
    RC_5_bit += 1;
    RC_5_transmission.data <<= 1;//
  }

  // Alternate between the first bit period and the second bit period
  bitState ^= 1;
}
// Setup and start the transmission of an RC-5 packet
void RC_5_transmit(uint32_t toggle, uint32_t addr, uint32_t command)
{
  RC_5_transmission.packet.start_1 = 0x1;
  RC_5_transmission.packet.start_2 = 0x1;
  RC_5_transmission.packet.toggle = toggle & 0x1;
  RC_5_transmission.packet.addr = addr & 0x1F;
  RC_5_transmission.packet.command = command & 0x3F;
  RC_5_transmission.data = RC_5_transmission.data&0x3FFF;
  temp_data = RC_5_transmission.data;
  RC_5_bit = 0;
  TIMER_CounterSet(TIMER1, 0);
  TIMER_Enable(TIMER1, 1);
  RC_5_TX_complete = false;
}

void RC_5_init(void)
{
  WTIMER0_init(); // capture Periods phototransistor input
  // Timer 0 provides the 36 kHz pulse trains
  TIMER0_init();
  // Timer 1 handles the packet transmission in its IRQ Handler
  TIMER1_init();
}
void WTIMER0_IRQHandler(void)
{
  // Get pending flags and clear
  int irq_flags = TIMER_IntGet(WTIMER0);
  TIMER_IntClear(WTIMER0, WTIMER_IF_CC2 | WTIMER_IF_OF);

  // Read the last captured value from the CC register
  uint32_t current_edge = TIMER_CaptureGet(WTIMER0, 2);
  // Check if timer overflow occurred
  if(irq_flags & WTIMER_IF_OF)
  {
    overflow_count++;
  }
  if(irq_flags & WTIMER_IF_CC2)
  {
    // Calculate period in microseconds, while compensating for overflows
    // Interrupt latency will affect measurements for periods below 3 microseconds (333 kHz)
    measured_period = (overflow_count*(TIMER_TopGet(WTIMER0) + 2) - last_captured_edge + current_edge)
    		          / (HFPERCLK_IN_MHZ * (1 << WTIMER0_PRESCALE));

    // Store edge for next period
    last_captured_edge = current_edge;
    // Reset overflow count
    overflow_count = 0;
    periodsArray[i] = measured_period;//periodo
    RC5_DataSampling(measured_period, edge, RC5TmpPacket.lastBit);
    edge^=1;
    i++;
   }
}


