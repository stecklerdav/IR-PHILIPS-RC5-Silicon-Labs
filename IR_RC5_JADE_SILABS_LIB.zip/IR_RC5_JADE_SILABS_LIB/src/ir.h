/*
 * ir.h
 *
 *  Created on: 5 de may. de 2020
 *      Author: steckler
 */

#ifndef SRC_IR_H_
#define SRC_IR_H_

void RC5_ResetPacket(void);
void ReInitDecoderRc5(void);
void RC5_Decode();
void RC5_DataSampling(uint16_t rawPulseLength, uint8_t edge,uint8_t bitVal);
void RC5_modifyLastBit(tRC5_lastBitType bit,uint8_t bitVal);



#endif /* SRC_IR_H_ */
